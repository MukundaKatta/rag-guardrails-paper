# RAG Guardrails Figshare Package

This package prepares a supplementary research artifact for Figshare and Zenodo around two small guardrail packages in `ai-problem-packages`.

## Title

Small-Rule Guardrails for Retrieval-Augmented Generation: Prompt Injection and Vector Poisoning Checks

## Repository Basis

- `@mukundakatta/prompt-injection-shield`
- `@mukundakatta/vector-poison-score`

## Platform Fit

Figshare is a good fit for this item because the work is a compact research artifact: manuscript, source notes, package links, and a small reproducibility bundle. The paper is intentionally framed as an engineering note rather than a benchmark claim.

## Files

- `paper.md` - manuscript draft
- `abstract.txt` - upload-ready abstract
- `keywords.txt` - suggested keywords
- `paper.bib` - bibliography
- `submission-metadata.json` - structured metadata
- `assets/workflow-figure.svg` - simple workflow figure

